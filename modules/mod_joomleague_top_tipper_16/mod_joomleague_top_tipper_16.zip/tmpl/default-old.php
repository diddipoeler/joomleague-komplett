<?php
/**
* @version $Id: default.php 4902 2010-01-30 07:40:04Z and_one $
* @package Joomleague
* @subpackage player_birthday
* @copyright Copyright (C) 2009  JoomLeague
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see _joomleague_license.txt
*/

// no direct access
defined('_JEXEC') or die('Restricted access'); 

echo '<div>';
// ranking
echo $this->loadTemplate('ranking');

echo '</div>';


?>